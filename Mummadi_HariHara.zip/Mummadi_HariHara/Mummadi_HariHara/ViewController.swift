//
//  ViewController.swift
//  Mummadi_HariHara
//
//  Created by Mummadi,Hari Hara on 2/1/22.
//

import UIKit

class ViewController: UIViewController {

    
@IBOutlet weak var firstNameTextField: UITextField!
    
@IBOutlet weak var lastNameTextField: UITextField!

@IBOutlet weak var onClickOfSubmit: UIButton!
    
@IBOutlet weak var onClickOfReset: UIButton!
    
@IBOutlet weak var displayLabel: UILabel!
    
@IBOutlet weak var fullNameLabel: UILabel!
    
@IBOutlet weak var initialsLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func onClickOfSubmit(_ sender: UIButton) {
        var firstName = firstNameTextField.text!
        var lastName = lastNameTextField.text!
        let c1 = firstName.prefix(1);
        let c2 = lastName.prefix(1);
        fullNameLabel.text = " FullName: \(firstName), \(lastName)"
        initialsLabel.text = " Initials: \(c1)\(c2)"
        displayLabel.text = "Details"
     
    }
    
    @IBAction func onClickOfReset(_ sender: UIButton)
    {
        firstNameTextField.text! = " "
        lastNameTextField.text! = " "
        displayLabel.text! = " "
        fullNameLabel.text! = " "
        initialsLabel.text! = " "
        firstNameTextField.becomeFirstResponder()
        
    }
    
}

